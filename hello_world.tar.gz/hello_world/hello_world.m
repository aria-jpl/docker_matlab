% Hello World running in MATLAB/Docker 
% Author: Alexander Torres

function [] = hello_world
fprintf("Hello World!\n");